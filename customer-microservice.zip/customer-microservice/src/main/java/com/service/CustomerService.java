package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.controller.LoanApplicationRequest;
import com.model.Customer;
import com.model.LoanApplicationStatus;
import com.repository.CustomerRepository;
import com.repository.LoanApplicationStatusRepository;

import jakarta.validation.Valid;

@Service
public class CustomerService {
@Autowired
CustomerRepository customerRepository;
@Autowired
LoanApplicationStatusRepository loanApplicationStatusRepository;

 //register
public boolean existsByPanCardNumber(String panCardNumber) {
    return customerRepository.existsByPanCardNumber(panCardNumber);
}

public boolean existsByEmail(String email) {
    return customerRepository.existsByEmail(email);
}

public Customer addNewCustomer(@Valid Customer customer) {
	 return customerRepository.save(customer);}


//login
public String authenticate(String email, String password) {
	 Customer customer = customerRepository.findByEmail(email);
	    if (customer != null && customer.getPassword().equals(password)) {
	        return ("login successful");
	    }
	    return null;
}



//apply for loan
/*
public void applyForLoan(Long customerId, LoanApplicationStatus applicationStatus) {
    loanApplicationStatusRepository.save(applicationStatus);
}*/


public void applyForLoan(Long customerId,Integer loanId) {
    LoanApplicationStatus loanApplication = new LoanApplicationStatus();
    loanApplication.setCustomerId(customerId);
    loanApplication.setLoanId(loanId);  // Set loanId directly

    // Save the application
    LoanApplicationStatus.save(loanApplication);
}
}






