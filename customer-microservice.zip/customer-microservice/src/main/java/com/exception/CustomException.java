package com.exception;

public class CustomException extends Exception{

	public CustomException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
